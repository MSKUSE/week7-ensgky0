import java.util.ArrayList;

public class Librarian extends User {
    private ArrayList<Book> inventory = new ArrayList<>();

    public Librarian(int id, String name, String email, String password) {
        super(id, name, email, password);
    }

    public void addBook(Book book) {
        inventory.add(book);
    }

    public void removeBook(Book book) {
        inventory.remove(book);
    }

    public void printInventory() {
        if (inventory.isEmpty()) {
            System.out.println("(no books available)");
        } else {
            for (Book book : inventory) {
                System.out.println(book);
            }
        }
    }
}
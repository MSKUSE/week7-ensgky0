Library Management System - Java Assignment 1

How to compile:
    javac *.java

How to run:
    java Main

Description:
This project implements a simple library management system with User, Member, Librarian, and Book classes.